import { useEffect, useRef } from 'react';
import styled from 'styled-components';
import { formMarkup } from './formMarkup';
import { GlobalStyle } from './globalStyles';
import { initFamilyForm } from './familyForm';

const AppShell = styled.div`
  min-height: 100vh;
`;

function App() {
  const didInitRef = useRef(false);

  useEffect(() => {
    if (didInitRef.current) return;
    didInitRef.current = true;
    initFamilyForm();
  }, []);

  return (
    <>
      <GlobalStyle />
      <AppShell
        className="family3-body"
        dangerouslySetInnerHTML={{ __html: formMarkup }}
      />
    </>
  );
}

export default App;